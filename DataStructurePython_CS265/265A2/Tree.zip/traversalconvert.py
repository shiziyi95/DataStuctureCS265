from node import Node
from lcrstree import Tree

def Inorder(root):
    if root:
        # First recur on left child
        Inorder(root.left)
        # then print the data of node
        print(root.val),
        # now recur on right child
        Inorder(root.right)

def Postorder(root):
    if root:
        # First recur on left child
        Postorder(root.left)
        # the recur on right child
        Postorder(root.right)
        # now print the data of node
        print(root.val),
 
 
# A function to do postorder tree traversal
def Preorder(root):
 
    if root:
        # First print the data of node
        print(root.val),
 
        # Then recur on left child
        Preorder(root.left)
 
        # Finally recur on right child
        Preorder(root.right)


# Driver code
'''
t = Tree()
root = Node(10)
t.root = root
t.INSERT(1)
t.INSERT(20)
t.INSERT(5)
t.INSERT(15)
t.INSERT(7)
print "Preorder: "
Preorder(root)
print ""

print "Inorder: "
Inorder(root)
print ""

print "Postorder: "
Postorder(root)
print ""
'''