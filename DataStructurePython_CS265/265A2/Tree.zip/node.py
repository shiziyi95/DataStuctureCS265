class Node:
	def __init__(self,x):
		self.val = x
		self.next = None
		self.left = None
		self.right = None
		self.parent = None