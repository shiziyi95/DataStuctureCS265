from pointerqueues import Queue
from pointerqueues import Node

q = Queue()
q.ENQUEUE(1)
q.PrintQueue()
